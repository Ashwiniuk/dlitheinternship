package intern.dlithe.dlithejunit;

import java.util.Random;

import org.junit.Test;

public class bike {
	public int getRandom()
	{
		return new Random().nextInt(10);
	}
@Test
public void testRand() {
}
}

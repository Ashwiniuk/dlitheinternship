package bank.bankspring;

public class savings implements operation {

	private account ac;

	public account getAc() {
		return ac;
	}

	public void setAc(account ac) {
		this.ac = ac;
	}
	
	public void deposites() {
		// TODO Auto-generated method stub
		double bal=1000;
		double b=ac.getAccbal();
		double a=b+bal;
		ac.setAccbal(bal);
		System.out.println(ac.toString());
	}

	public void intrest() {
		double b=ac.getAccbal();
		double a=b+(b*(5.6/100));
		ac.setAccbal(b);
		System.out.println(ac.toString());
		
		// TODO Auto-generated method stub
		
	}
}

package bank.bankspring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class main {

	public static void main(String args[])
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");

		 operation p=(operation)context.getBean("savings");
		 p.deposites();
		 p.intrest();
		 p=(operation)context.getBean("current");
		 p.deposites();
		 p.intrest();
}
}
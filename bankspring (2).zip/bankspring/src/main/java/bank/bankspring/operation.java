package bank.bankspring;

public interface operation {

	public void deposites();
	public void intrest();
}

package spring.dlithespring;

public class furniture {
	private String name,type,usage;
	private int  price;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getUsage() {
		return usage;
	}
	public void setUsage(String usage) {
		this.usage = usage;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public furniture(String name, String type, String usage, int price) {
		super();
		this.name = name;
		this.type = type;
		this.usage = usage;
		this.price = price;
	}
	public furniture()
	{
	}
	@Override
	public String toString() {
		return "furniture [name=" + name + ", type=" + type + ", usage=" + usage + ", price=" + price + "]";
	}
}
	
	



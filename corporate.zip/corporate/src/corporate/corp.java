package corporate;
import java.util. *;


public class corp
{
private String campus;
private String role;
private int expected;
private int hiredcount;
private List<String> people=new ArrayList<>();

public String getCampus() {
		return campus;
	}
	public void setCampus(String campus) {
		this.campus = campus;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public int getExpected() {
		return expected;
	}
	public void setExpected(int expected) {
		this.expected = expected;
	}
	public int getHiredcount() {
		return hiredcount;
	}
	public void setHiredcount(int hiredcount) {
		this.hiredcount = hiredcount;
	}
	public List<String> getPeople() {
		return people;
	}
	public void setPeople(List<String> people) {
		this.people = people;
	}
public String toString() 
{
	return "candidate [campus=" + campus + ", role=" + role + ", expected=" + expected + ", hiredcount=" + hiredcount +",people=" + people +"]";
}

/*public static void main(String args[])
{
	Scanner Sc=new Scanner(System.in);
	System.out.println("Enter the  campus name:");
	String cname=Sc.nextLine();
	System.out.println("Enter the role:");
	String role=Sc.nextLine();
	System.out.println("Enter the expected sal");
	String sal=Sc.nextLine();
	System.out.println("Enter the hired count ");
	String count=Sc.nextLine();
	System.out.println("Enter the people name ");
	String pename=Sc.nextLine();
	corp c=new corp();
	//System.out.println(name+" "+cgpa+" "+skills+" "+email+" ");
	c.setCampus(cname);
	c.setRole(role);
	c.setExpected(sal);
	c.setHiredcount(count);
	//c.List<String>(penmae); 
//*	c.setPeople(penmae);
	System.out.println(c);
	}
}
*/
}


package dlithe.boot.core;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("odi")
public class Team
{
	private String country;
	@Autowired
	private Player captain;
	public Player getPlayer() {
		return captain;
	}
	public void setPlayer(Player player) {
		this.captain = player;
	}
	private List<Player> members=new ArrayList<Player>();
	public Team() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Team [country=" + country + ", player=" + captain.toString() + ", members=" + members + "]";
	}

	public Team(String country, Player player, List<Player> members) {
		super();
		this.country = country;
		this.captain = player;
		this.members = members;
	}

	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public List<Player> getMembers() {
		return members;
	}
	public void setMembers(List<Player> members) {
		this.members = members;
	}
}

package bank.bankspring;

public class account {

	private String accno;
	private double accbal;
	public String getAccno() {
		return accno;
	}
	public void setAccno(String accno) {
		this.accno = accno;
	}
	public double getAccbal() {
		return accbal;
	}
	public void setAccbal(double accbal) {
		this.accbal = accbal;
	}
	public account(String accno, double accbal) {
		super();
		this.accno = accno;
		this.accbal = accbal;
	}
	public void account()
	{
		
	}
	@Override
	public String toString() {
		return "account [accno=" + accno + ", accbal=" + accbal + "]";
	}
	
}
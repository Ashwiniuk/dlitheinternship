package mockitodlithe.mockitd;
import java.util.ArrayList;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
@RunWith(MockitoJUnitRunner.class)
public class test {
		List<Mobile> mb1=null;Mobile m1=null,m2=null,m3=null,m4=null;
		public test()
		{
			mb1=new ArrayList<Mobile>();
			m1=new Mobile("6.1", "Nokia", 12, 16700);
			m2=new Mobile("Note3", "Redmi", 34, 11000);
			m3=new Mobile("iPhoneXs", "Apple", 5, 153300);
			m4=new Mobile("7Pro","OnePlus",12,53000);
			mb1.add(m1);mb1.add(m2);mb1.add(m3);mb1.add(m4);
		}
		@InjectMocks
		implementation imp=new implementation();
		@Mock
		mob dlithe;
		@Test
		public void testCreate()
		{
			List donut=null;
			Mockito.when(dlithe.create(mb1)).thenReturn(true);
			Assert.assertTrue(dlithe.create(mb1));
			Mockito.verify(dlithe).create(mb1);
		}
		@Test(expected=RuntimeException.class)
		public void testSum()
		{
			Mockito.when(imp.sum(m1)).thenReturn(imp.sum(m1));
			Assert.assertEquals(dlithe.sum(m1), imp.sum(m1));
			Mockito.verify(dlithe).sum(m1);
		}
		@Test
		public void testRead()
		{Mockito.when(dlithe.read(0)).thenReturn(m2);
		Assert.assertEquals(m1, dlithe.read(0));
		}
		@Test
		public void testList()
		{
			List donut=null;
			Mockito.when(dlithe.list()).thenReturn(mb1);
			Assert.assertEquals(mb1, dlithe.list());
			Mockito.verify(dlithe).list();
		}
	}
	
package hostel.pg;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
@Entity

public class college {
	
	@Id
	private String usn;
	private String section;
	@OneToOne
	public String getUsn() {
		return usn;
	}
	public void setUsn(String usn) {
		this.usn = usn;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	@Override
	public String toString() {
		return "college [usn=" + usn + ",  section=" + section + "]";
	}
	public college(String usn,  String section) {
		super();
		this.usn = usn;

		this.section = section;
	}
	public void college()
	{
		
	}

}

package sample;

import java.time.LocalDate;
import java.util.*;
public class inteface1 {
private String EventName;
private LocalDate Date;
private String Dept;
private String Coord;
private String C_ContactInfo;
private String Prize;
private String P_Name;
private String W_Name;

public String getEventName() {
	return EventName;
}
public void setEventName(String eventName) {
	EventName = eventName;
}
public LocalDate getDate() {
	return Date;
}
public void setDate(LocalDate date) {
	Date = date;
}
public String getDept() {
	return Dept;
}
public void setDept(String dept) {
	Dept = dept;
}
public String getCoord() {
	return Coord;
}
public void setCoord(String coord) {
	Coord = coord;
}
public String getC_ContactInfo() {
	return C_ContactInfo;
}
public void setC_ContactInfo(String c_ContactInfo) {
	C_ContactInfo = c_ContactInfo;
}
public String getPrize() {
	return Prize;
}
public void setPrize(String prize) {
	Prize = prize;
}
public String getP_Name() {
	return P_Name;
}
public void setP_Name(String p_Name) {
	P_Name = p_Name;
}
public String getW_Name() {
	return W_Name;
}
public void setW_Name(String w_Name) {
	W_Name = w_Name;
}
public inteface1() {}

public inteface1(String eventName, LocalDate date, String dept, String coord, String c_ContactInfo, String prize,
		String p_Name, String w_Name) {
	super();
	EventName = eventName;
	Date = date;
	Dept = dept;
	Coord = coord;
	C_ContactInfo = c_ContactInfo;
	Prize = prize;
	P_Name = p_Name;
	W_Name = w_Name;
}
void Display()
{
	System.out.println("Event Name : "+EventName);
	System.out.println("Date : "+Date);
	System.out.println("Dept : "+Dept);
	System.out.println("Co-ordinator Name : "+Coord);
	System.out.println("Co-ordinator Num : "+C_ContactInfo);
	System.out.println("Prize Pool : "+Prize);
	System.out.println("Participator name : "+P_Name);
	System.out.println("Winner name : "+W_Name);
}

@Override
public String toString() {
	return "inteface1 [EventName=" + EventName + ", Date=" + Date + ", Dept=" + Dept + ", Coord=" + Coord
			+ ", C_ContactInfo=" + C_ContactInfo + ", Prize=" + Prize + ", P_Name=" + P_Name + ", W_Name=" + W_Name
			+ "]";
}
public static void main(String args[])
{
	/*EventManagement E1=new EventManagement("Cricket","11/10/2019","2.30PM","CSE","Madhu","9876543210","5000");
	E1.Display();*/
	Scanner Sc=new Scanner(System.in);
	inteface1 i=new inteface1();
	System.out.println("Enter the event Name:");
	String EName=Sc.nextLine();
	System.out.println("Enter the event Date:");
	String EDate=Sc.nextLine();
	System.out.println("Enter the Department");
	String Dept=Sc.nextLine();
	System.out.println("Enter the event Co-0rdinator Name:");
	String Coord=Sc.nextLine();
	System.out.println("Enter the event Co-ordinator Number:");
	String Enum=Sc.nextLine();
	System.out.println("Enter the event Prize:");
	String EPrize=Sc.nextLine();
	System.out.println("Enter participator name:");
	String Pname=Sc.nextLine();
	System.out.println("Enter the winner name");
	String Wname=Sc.nextLine();
	LocalDate LDate=LocalDate.parse(EDate);
	//inteface1 E2=new inteface1 (EName,LDate,Dept,Coord,Enum,EPrize);
	System.out.println(EName+" "+LDate+" "+Dept+" "+Coord+" "+Enum+" "+EPrize);
	i.setEventName(EName);
	i.setDate(LDate);
	i.setDept(Dept);
	i.setCoord(Coord);
	i.setC_ContactInfo(Enum);
	i.setPrize(EPrize);
	i.setP_Name(Pname);
	i.setW_Name(Wname);
	System.out.println(i);
	


	
}

}
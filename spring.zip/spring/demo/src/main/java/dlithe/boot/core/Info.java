package dlithe.boot.core;

import java.util.List;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
public class Info 
{
	Logger log=LoggerFactory.getLogger(this.getClass());
	@Before("execution(public List<Player> getMembers())")
	public void info1()
	{log.info("Player going to added in team");}
	@Before("execution(witnin(dlithe.boot.core.Team))")
	public void info2()
	{log.info("Read info");}
}

package sample;

public class participantsNotFoundException extends Exception {
	public participantsNotFoundException (String message) {
		super(message);
	}

}

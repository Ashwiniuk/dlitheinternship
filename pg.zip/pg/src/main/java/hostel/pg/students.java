package hostel.pg;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table
public class students {
	@Id
	private String  usn;
	private String  name;
	private String  Address;
	
	private int  phonno;
	
	public String getUsn() {
		return usn;
	}


	public void setUsn(String usn) {
		this.usn = usn;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return Address;
	}


	public void setAddress(String address) {
		Address = address;
	}


	public int getPhonno() {
		return phonno;
	}


	public void setPhonno(int phonno) {
		this.phonno = phonno;
	}
	@Override
	public String toString() {
		return "students [usn=" + usn + ", name=" + name + ", Address=" + Address + ", phonno=" + phonno + "]";
	}
	public students(String usn, String name, String address, int phonno) {
		super();
		this.usn = usn;
		this.name = name;
		Address = address;
		this.phonno = phonno;
	}


	public students()
	{
		
	}
	
	

}

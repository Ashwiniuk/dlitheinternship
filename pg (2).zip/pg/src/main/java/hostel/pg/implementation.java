package hostel.pg;
import java.util.List;

import org.hibernate.Query;

//import javax.management.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class implementation {
	
	SessionFactory factory=null;
	Session session=null;
	
	
public void create()
{
	SessionFactory factory=new Configuration().configure().buildSessionFactory();
	Session session=factory.openSession();
	session.beginTransaction();
	students s1=new students("12ab3","ash","manchi",9854);
	students s2=new students("12ab32","ashiwni","manchole",98548);
	session.save(s1);
	session.save(s2);
	session.getTransaction().commit();
	session.close();

}

public void update()
{
	SessionFactory factory=new Configuration().configure().buildSessionFactory();
	Session session=factory.openSession();
	session.beginTransaction();
	students rt=(students)session.get(students.class, "12ab3");
	rt.setName("ashhhh");
	session.update(rt);
	session.getTransaction().commit();
	session.close();

	}
public void delete()
{   SessionFactory factory=new Configuration().configure().buildSessionFactory();
    Session session=factory.openSession();
    session.beginTransaction();
    
    
    students temp=(students)session.get(students.class, "12ab3");  // read
    session.delete(temp);
    session.getTransaction().commit();
	session.close();
  
}
public void list()
{
	SessionFactory factory=new Configuration().configure().buildSessionFactory();
    Session session=factory.openSession();
    session.beginTransaction();
    Query qry=session.createQuery("select name from students");
    List<students> p=qry.list();
    System.out.println(p);
    session.getTransaction().commit();
  	session.close();
    
}
public void read()
{
	SessionFactory factory=new Configuration().configure().buildSessionFactory();
    Session session=factory.openSession();
    session.beginTransaction();
    students temp=(students)session.get(students.class, "12ab3");
    System.out.println(temp);
    session.getTransaction().commit();
  	session.close();
}
}


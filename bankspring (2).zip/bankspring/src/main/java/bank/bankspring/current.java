package bank.bankspring;

public class current implements operation 
{
	private account cur;
	

	public account getCur() {
		return cur;
	}

	public void setCur(account cur) {
		this.cur = cur;
	}

	public void deposites() 
	{
		
		double bal=1000;
		if(bal>20000) {
			double a=cur. getAccbal();
		double b=a+bal;
		cur. setAccbal(b);
		System.out.println(cur.toString());
		}
		else	
		{
			System.out.println("minimum deposite has to be 20000");
		}
	}

	public void intrest() {
		double a=cur.getAccbal();
		double b=a+(a*(0/100));
		cur.setAccbal(b);
		System.out.println(cur.toString());
	}
	
	

}

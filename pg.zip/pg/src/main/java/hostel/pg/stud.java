package hostel.pg;

public interface stud {
	public void create();
	public void delete();
	public void read();
	public void update();
	public void list();
	

}

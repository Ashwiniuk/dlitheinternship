package dlithe.boot.core;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.stereotype.Component;

@Component("captain")
public class Player implements BeanNameAware
{
	private String name, state, type, temp;int age;
	@Override
	public String toString() {
		return "Player [name=" + name + ", state=" + state + ", type=" + type + ", age=" + age + "]";
	}
	public Player() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Player(String name, String state, String type, int age) {
		super();
		this.name = name;
		this.state = state;
		this.type = type;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public void setBeanName(String name) {
		// TODO Auto-generated method stub
		temp=name;System.out.println(temp);
	}
	
}

package swathi.hi;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import rec;

public class App 
{
	SessionFactory factory = null;
	Session session =null;
	
	public App()
	{
		System.out.println("Welcome to Recruitment Process");
    	factory = new Configuration().configure().buildSessionFactory();
    	session = factory.openSession();
    	session.beginTransaction();
	}
	
	rec c =new rec();
	
	public void create()
	{
		  rec c1 = new rec("tcs", "Java Developer", 5, 4, "hita,hith"); 
		  rec c2 = new rec("accenture", "tester", 4, 3, "Preston,dsouza"); 
		  rec c3 = new rec("wipro", "Analyst", 3, 3, "swathi, Likith"); 
		  rec c4 = new rec ("evry", "web Designer", 4, 4, "ashwini, Mahantesh"); 
		  session.save(c1); session.save(c2);
		  session.save(c3); session.save(c4);
	}
	
	
	public void update()
	{

		rec c=(rec)session.get(rec.class, "tcs");
		c.setExpcount(2); 
		session.update(c);
	}
	
	public void delete()
	{
		rec  c=(rec )session.get(rec.class, "accenture");
		 session.delete(c);
	}
	
	public void list()
	{
		Query q = session.createQuery("select people from rec");
    	List<rec> pool = q.list();
    	System.out.println(pool);
	}
	
	public void find()
	{
		System.out.println();
    	System.out.println();
    	Query q=session.createQuery("from rec where role='tester' and hiredcount=expcount");
    	List<rec> qu = q.list();
    	System.out.println(qu);
    	
	}

	public void end()
	{
		session.getTransaction().commit();
    	session.close();
	}
	
    public static void main( String[] args )
    {   
    	App a = new App();
    	a.create();
    	a.update();
    	a.delete();
    	a.list();
    	a.find();
    	a.end();
    }
}

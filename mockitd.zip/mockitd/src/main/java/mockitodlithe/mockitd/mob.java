package mockitodlithe.mockitd;

import java.util.List;

public interface mob {
	public boolean create(List<Mobile> temp);
	public double sum(Mobile mob);
	public Mobile read(int index);
	public boolean update(int index, Mobile mob);
	public List<Mobile> list();
}




package bank.bankspring;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class main {

	public static void main(String args[])
	{
		 AbstractApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		 operation p=(operation)context.getBean("savings");
		 p.deposites();
		 p.intrest();
		 p=(operation)context.getBean("current");
		 p.deposites();
		 p.intrest();
	       
}
}
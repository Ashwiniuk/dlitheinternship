package dlithe.BShowroom;

public interface CustomerInterface 
{
	public void CreateCustomer();
	public void UpdateCustomer();
	public void DeleteCustomer();
	public void ListCustomer();
}

package mockitodlithe.mockitd;

import org.junit.internal.runners.TestClass;
import org.junit.runner.JUnitCore;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

    	System.out.println( "Hello World!" );
    	Result res=JUnitCore.runClasses(test.class);
    	List <Failure> fails=res.getFailures();
    	for(Failure fa:fails) {System.out.println(fa.toString());}
    	System.out.println(res.wasSuccessful());
    }
}
        		


      
        

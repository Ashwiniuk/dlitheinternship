package dlithe.BShowroom;

public interface SRInterface 
{
	public void CreateShowroom();
	public void UpdateShowroom();
	public void DeleteShowroom();
	public void ListShowroom();
}

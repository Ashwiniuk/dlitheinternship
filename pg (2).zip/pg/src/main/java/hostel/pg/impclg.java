package hostel.pg;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Query;

public class impclg {

//import javax.management.Query;
       SessionFactory factory=null;
		Session session=null;
		
		public void create()
	{
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
		Session session=factory.openSession();
		session.beginTransaction();
		college c1=new college("12ab44","a");
		college c2=new college("12ab66","b");
		session.save(c1);
		session.save(c2);
		session.getTransaction().commit();
		session.close();

	}
}
/*	public void update()
	{
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
		Session session=factory.openSession();
		session.beginTransaction();
		college rt=(college)session.get(college.class, "12ab44");
		rt.setSection("d");
		session.update(rt);
		session.getTransaction().commit();
		session.close();

		}
	public void delete()
	{   SessionFactory factory=new Configuration().configure().buildSessionFactory();
	    Session session=factory.openSession();
	    session.beginTransaction();
	    
	    
	    students temp=(students)session.get(students.class, "12ab3");  // read
	    session.delete(temp);
	    session.getTransaction().commit();
		session.close();
	  
	}
	public void list()
	{
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
	    Session session=factory.openSession();
	    session.beginTransaction();
	    Query qry=session.createQuery("select name from students");
	    List<students> p=qry.list();
	    System.out.println(p);
	    session.getTransaction().commit();
	  	session.close();
	    
	}
	public void read()
	{
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
	    Session session=factory.openSession();
	    session.beginTransaction();
	    students temp=(students)session.get(students.class, "12ab3");
	    System.out.println(temp);
	    session.getTransaction().commit();
	  	session.close();
	}*/
	





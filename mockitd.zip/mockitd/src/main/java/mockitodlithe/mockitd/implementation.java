package mockitodlithe.mockitd;



import java.util.List;
public class implementation

{
	private mob mb;
	public void setmb(mob mb) {
		this.mb = mb;
	}
	public boolean create(List<Mobile> temp) {return mb.create(temp);}
	public double sum(Mobile mob) 
	{
		return mob.getPrice()*mob.getQty();
	}
	public Mobile read(int index) {return mb.read(index);}
	public boolean update(int index,Mobile mob) {return mb.update(index, mob);}
	public List<Mobile> list(){return mb.list();}
}
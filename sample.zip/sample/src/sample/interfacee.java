package sample;
import java.time.  *;
public interface interfacee
{
	public void insert(inteface1 in); 
	public void delete(inteface1 in) throws EventNotFoundException, participantsNotFoundException;
	public void update(inteface1 in,String W_Name);
	public void list();
	public void addparticipent(inteface1 in,String p_name) throws EventNotFoundException, participantsNotFoundException;
	public void search (String date);
	
	
	
}

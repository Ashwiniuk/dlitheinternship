package corporate;
import java.util. *;
import java.util.TreeSet;

public class set {
	Scanner sc=new Scanner(System.in);
	TreeSet<String> set=new TreeSet<String>();
	corp c=new corp();
	public void create()
	{   
		System.out.println("Enter the campus");
		String campus=sc.nextLine();
		System.out.println("enter the role");
		
	    
	}

}

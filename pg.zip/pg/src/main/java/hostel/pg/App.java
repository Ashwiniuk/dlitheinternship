package hostel.pg;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "welcome" );
        implementation imp=new implementation();
       imp.create();
      //imp.update();
      // imp.delete();
       // imp.list();
     //  imp.read();
    }
}


import java.util.ArrayList;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="corporate")
public class rec {
        @Column(name="campname")
        private String campus;
private String role;
@Id @GeneratedValue(strategy=GenerationType.AUTO)
private Integer campid;
private int expcount;
public rec(String campus, String role, int expcount, int hiredcount, String people) {
super();
this.campus = campus;
this.role = role;
this.expcount = expcount;
this.hiredcount = hiredcount;
this.people = people;
}
private int hiredcount;
private String people;
public rec() {}
public String getCampus() {
return campus;
}
public void setCampus(String campus) {
this.campus = campus;
}
public String getRole() {
return role;
}
public void setRole(String role) {
this.role = role;
}
public int getExpcount() {
return expcount;
}
public void setExpcount(int expcount) {
this.expcount = expcount;
}
public int getHiredcount() {
return hiredcount;
}
public void setHiredcount(int hiredcount) {
this.hiredcount = hiredcount;
}
public String getPeople() {
return people;
}
public void setPeople(String people) {
this.people = people;
}
@Override
public String toString() {
return "Corporate [campus=" + campus + ", role=" + role + ", expcount=" + expcount + ", hiredcount="
+ hiredcount + ", people=" + people + "]";
}



// TODO Auto-generated constructor stub
}
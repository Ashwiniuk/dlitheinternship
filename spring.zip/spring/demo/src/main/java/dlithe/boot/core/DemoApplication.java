package dlithe.boot.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(DemoApplication.class, args);
		/*Player play=(Player)context.getBean("player");
		play.setName("Pawan");play.setAge(22);play.setState("AP");play.setType("Batsman");
		System.out.println(play);*/
		Team team=(Team)context.getBean("odi");
		team.setCountry("India");
		team.getMembers().add(new Player("Anirudh", "Karnataka", "Batsman", 23));
		team.getMembers().add(new Player("Bharath", "Karnataka", "All rounder", 25));
		team.getMembers().add(new Player("Ashwini", "Karnataka", "All rounder", 23));
		team.getMembers().add(new Player("Jegan", "Karnataka", "All rounder", 21));
		team.setPlayer(new Player("Pawan","AP","Batsman",22));
		System.out.println(team);
	}

}
